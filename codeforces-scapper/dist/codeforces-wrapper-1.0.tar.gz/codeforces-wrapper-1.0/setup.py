from setuptools import setup, find_packages

setup(
	name="codeforces-wrapper",
	version="1.0",
	description="Codeforces API Wrapper",
	url="https://github.com/synnek1337/gci-2019",
	author="Emilian Zawrotny",
	author_email="synnek1337@protonmail.com",
	packages=find_packages()
)